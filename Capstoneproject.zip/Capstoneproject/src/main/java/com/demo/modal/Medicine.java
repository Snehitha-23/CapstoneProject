package com.demo.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Entity
@Table
@NoArgsConstructor
@AllArgsConstructor

public class Medicine {
	@Id
	@GeneratedValue
    private int id;
private String name;
private int price;
private String seller;
private String productDescription;
private String instructions;
@Lob
@Column(columnDefinition="CLOB")
private String avatar;
@ManyToOne
private Cart cart;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
public String getSeller() {
	return seller;
}
public void setSeller(String seller) {
	this.seller = seller;
}
public String getProductDescription() {
	return productDescription;
}
public void setProductDescription(String productDescription) {
	this.productDescription = productDescription;
}
public String getInstructions() {
	return instructions;
}
public void setInstructions(String instructions) {
	this.instructions = instructions;
}
public String getAvatar() {
	return avatar;
}
public void setAvatar(String avatar) {
	this.avatar = avatar;
}
@Override
public String toString() {
	return "Medicine [id=" + id + ", name=" + name + ", price=" + price + ", seller=" + seller + ", productDescription="
			+ productDescription + ", instructions=" + instructions + ", avatar=" + avatar + "]";
}

	
	
	
	
	
	
	
	
	
	
	
	
}
