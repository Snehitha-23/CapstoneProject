package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.modal.Admin;
import com.demo.service.AdminService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class AdminController {
@Autowired
public AdminService service;



@PostMapping("/admin")
public Admin addAdmin(@RequestBody Admin admin) {
	return service.addAdmin(admin);
}

	@GetMapping("/admin/{Id}")
	public Admin getAdminById(@PathVariable int ID) {
	
		return service.getAdminById(ID);
	}

	@GetMapping("/admin/{emailId}")
	public Admin getAdminByEmailId(@PathVariable String emailId) {
		
		return service.getAdminByEmailId(emailId);
	}
//	@PostMapping("/adminauthenticate/{emailId}/{pwd}")
//	public String authenticate(@PathVariable String emailId,@PathVariable String pwd) {
//		
//		return service.authenticate(emailId,pwd);
//	}

	@PostMapping("/adminauthenticate")
	public Admin authenticate(@RequestBody Admin admin) throws Exception {
		
		return service.authenticate(admin);
	}

	
	@PutMapping("/admin")
	public void updateUser(@RequestBody Admin admin) {
	service.updateAdmin(admin);
		
	}

	@GetMapping("/admins")
	public List<Admin> getAllAdmins() {
	
		return service.getAllAdmins();
	}
	
	
}
	
	
	
	
	