package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.modal.User;
import com.demo.service.UserService;
@CrossOrigin(origins="http://localhost:4200")
@RestController
public class UserController {
@Autowired
public UserService service;
@PostMapping("/user")
public User addUser(@RequestBody User user) {
	return service.addUser(user);
}

	@GetMapping("/user/{Id}")
	public User getUserById(@PathVariable int ID) {
	
		return service.getUserById(ID);
	}

	@GetMapping("/user/emailId")
	public User getUserByEmailId(@PathVariable String emailId) {
		
		return service.getUserByEmailId(emailId);
	}
	

	@PutMapping("/user")
	public void updateUser(@RequestBody User user) {
	service.updateUser(user);
		
	}

	@GetMapping("/users")
	public List<User> getAllUsers() {
	
		return service.getAllUsers();
	}
	
	
	@PostMapping("/user/login")
	public User Login(@RequestBody User user) throws Exception
	{
		String emailId=user.getEmailId();
		String pwd=user.getPwd();
		
		User userobj=null;

		if(emailId!=null && pwd!=null)

		{
			userobj=service.getUserByEmailIdAndPwd(emailId, pwd);

		}
		if(userobj==null)
		{
       throw new Exception("Invalid credentials");
}
	return userobj;

		}
		
	
	@PostMapping("/user/register")
		public User Register(@RequestBody User user) throws Exception {
			String emailId=user.getEmailId();
			String pwd=user.getPwd();
			User userobj=null;
			
			
			if(emailId!=null && pwd!=null)
			{
				userobj=service.getUserByEmailIdAndPwd(emailId, pwd);
				
			}
			
			if(service.getUserByEmailId(emailId)==null&&userobj==null)
			{
			 return service.addUser(user);
			}
			else {
				throw new Exception("User Already Exists");
			}
			
		}
	
	
	

	
	@GetMapping("/user/emailid/{emailid}/pwd/{pwd}")

	public User getUserByEmailIdAndPwd(@PathVariable String emailId,@PathVariable String pwd) {

		return service.getUserByEmailIdAndPwd(emailId, pwd);

	}
	
	
	
}
