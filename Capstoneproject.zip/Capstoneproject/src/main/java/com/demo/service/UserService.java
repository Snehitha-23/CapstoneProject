package com.demo.service;

import java.util.List;

import com.demo.modal.User;

public interface UserService {

	public boolean authenticate(String emailId,String pwd);
	public User getUserById(int ID);
	public User getUserByEmailId(String emailId);
	public void updateUser(User user);
	public List<User>getAllUsers();
	public User addUser(User user);
	public User getUserByEmailIdAndPwd(String emailId, String pwd);
	

}
