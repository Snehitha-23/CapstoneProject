package com.demo.service;

import java.util.List;

import com.demo.modal.Admin;

public interface AdminService {
	public Admin authenticate(Admin admin) throws Exception;
	public Admin getAdminById(int ID);
	public Admin getAdminByEmailId(String emailId);
	public void updateAdmin(Admin admin);
	public List<Admin>getAllAdmins();
	public Admin addAdmin(Admin admin);
	
}
