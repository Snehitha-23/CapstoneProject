package com.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.AdminDao;
import com.demo.modal.Admin;
import com.demo.service.AdminService;
@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminDao adminDAO;
	
	
	@Override
	public Admin authenticate(Admin admin) throws Exception {
		// TODO Auto-generated method stub
		if(adminDAO.existsByEmailId(admin.getEmailId())&&adminDAO.findByEmailId(admin.getEmailId()).equals(adminDAO.findByPwd(admin.getPwd()))) {
			return admin;
		}
		else
		throw new Exception("invalid "); 
	}

	@Override
	public Admin getAdminById(int ID) {
		return adminDAO.findById(ID).get();
	}

	@Override
	public Admin getAdminByEmailId(String emailId) {
		return adminDAO.findByEmailId(emailId);	
	}

	@Override
	public void updateAdmin(Admin admin) {
		// TODO Auto-generated method stub
		adminDAO.save(admin);
	}

	@Override
	public List<Admin> getAllAdmins() {
		// TODO Auto-generated method stub
		return adminDAO.findAll();
	}

	@Override
	public Admin addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminDAO.save(admin);
	}

}
