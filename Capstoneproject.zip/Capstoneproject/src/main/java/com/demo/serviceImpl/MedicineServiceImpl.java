package com.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.MedicineDao;
import com.demo.modal.Medicine;
import com.demo.service.MedicineService;
@Service
public class MedicineServiceImpl implements MedicineService {
@Autowired
private MedicineDao dao;
	@Override
	public Medicine addMedicine(Medicine medicine) {
		// TODO Auto-generated method stub
		return dao.save(medicine);
	}

	@Override
	public Medicine updateMedicine(Medicine medicine) {
		// TODO Auto-generated method stub
		return dao.save(medicine);
	}

	@Override
	public Medicine getMedicineById(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id).get();
	}

	@Override
	public void deleteMedicineById(int id) {
		// TODO Auto-generated method stub
		dao.deleteById(id);
		
	}

	@Override
	public List<Medicine> getAllMedicines() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

}
