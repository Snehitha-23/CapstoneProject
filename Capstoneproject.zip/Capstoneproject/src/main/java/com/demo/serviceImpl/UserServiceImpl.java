package com.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.UserDao;
import com.demo.modal.User;
import com.demo.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserDao userDAO;
	
	@Override
	public boolean authenticate(String emailId, String pwd) {
	
	
		
	if(userDAO.existsByEmailId(emailId)&&userDAO.findByEmailId(emailId).equals(userDAO.findByPwd(pwd))) {
		return true;
	}
	else
	return false;
	}

	@Override
	public User getUserById(int ID) {
	
		return userDAO.findById(ID).get();
	}

	@Override
	public User getUserByEmailId(String emailId) {
		
		return userDAO.findByEmailId(emailId);
	}

	@Override
	public void updateUser(User user) {
		userDAO.save(user);
		
	}

	@Override
	public List<User> getAllUsers() {
	
		return userDAO.findAll();
	}

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return userDAO.save(user);
	}

	@Override
	public User getUserByEmailIdAndPwd(String emailId, String pwd) {
		// TODO Auto-generated method stub
		return userDAO.findByEmailIdAndPwd(emailId, pwd);
	}


}
