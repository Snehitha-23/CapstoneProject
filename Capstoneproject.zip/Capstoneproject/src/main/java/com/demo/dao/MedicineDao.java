package com.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.modal.Medicine;
@Repository
public interface MedicineDao extends JpaRepository<Medicine,Integer> {

}
