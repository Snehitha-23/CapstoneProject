package com.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.modal.User;
@Repository
public interface UserDao extends JpaRepository<User,Integer> {
	public User findByEmailId(String emailId);
	public User findByPwd(String pwd);
	public User findByEmailIdAndPwd(String emailId,String pwd);
	public boolean existsByEmailId(String emailId);
}
