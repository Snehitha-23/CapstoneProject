package com.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.demo.modal.Admin;

@Repository
public interface AdminDao extends JpaRepository<Admin,Integer> {
	public Admin findByEmailId(String emailId);
	public Admin findByPwd(String pwd);
	public boolean existsByEmailId(String emailId);
}